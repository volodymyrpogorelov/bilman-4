Checkout http://rtfm.modx.com/display/ADDON/MinifyX
