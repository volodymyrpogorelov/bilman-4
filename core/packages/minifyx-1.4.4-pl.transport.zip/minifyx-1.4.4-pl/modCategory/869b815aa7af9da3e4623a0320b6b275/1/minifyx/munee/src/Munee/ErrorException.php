<?php
/**
 * Munee: Optimising Your Assets
 *
 * @copyright Cody Lundquist 2013
 * @license http://opensource.org/licenses/mit-license.php
 */

namespace Munee;

/**
 * Class ErrorException
 *
 * @author Cody Lundquist
 */
class ErrorException extends \Exception {}