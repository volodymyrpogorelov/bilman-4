<?php
require_once (dirname(dirname(__FILE__)) . '/jgslideshowslide.class.php');
class jgSlideshowSlide_mysql extends jgSlideshowSlide {}