<?php
class jgSlideshowSlide extends xPDOSimpleObject {}