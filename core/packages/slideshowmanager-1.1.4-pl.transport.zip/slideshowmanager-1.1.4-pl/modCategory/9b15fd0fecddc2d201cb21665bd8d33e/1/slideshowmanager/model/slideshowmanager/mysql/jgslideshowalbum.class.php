<?php
require_once (dirname(dirname(__FILE__)) . '/jgslideshowalbum.class.php');
class jgSlideshowAlbum_mysql extends jgSlideshowAlbum {}