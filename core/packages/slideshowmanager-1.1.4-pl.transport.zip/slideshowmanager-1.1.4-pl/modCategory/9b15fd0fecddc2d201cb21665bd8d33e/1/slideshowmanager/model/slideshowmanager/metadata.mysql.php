<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'jgSlideshowAlbum',
    1 => 'jgSlideshowSlide',
  ),
);