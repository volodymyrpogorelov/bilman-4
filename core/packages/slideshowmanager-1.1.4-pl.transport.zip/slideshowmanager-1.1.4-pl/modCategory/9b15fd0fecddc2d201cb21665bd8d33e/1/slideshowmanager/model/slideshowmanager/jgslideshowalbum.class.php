<?php
class jgSlideshowAlbum extends xPDOSimpleObject {}