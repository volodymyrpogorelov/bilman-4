tinyMCE.addI18n('tt.modxlink',{
    link_desc:"Insert/edit link"
});