tinyMCE.addI18n('nb.modxlink',{
    link_desc:"Insert/edit link"
});