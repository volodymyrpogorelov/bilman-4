tinyMCE.addI18n({hu:{
common:{
edit_confirm:"Haszn\u00E1lni k\u00EDv\u00E1nja a WYSIWYG m\u00F3dot ebben a sz\u00F6vegdobozban?",
apply:"Alkalmaz\u00E1s",
insert:"Besz\u00FAr\u00E1s",
update:"Friss\u00EDt\u00E9s",
cancel:"M\u00E9gsem",
close:"Bez\u00E1r\u00E1s",
browse:"Tall\u00F3z\u00E1s",
class_name:"Oszt\u00E1ly",
not_set:"-- Nincs megadva --",
clipboard_msg:"A M\u00E1sol\u00E1s/Kiv\u00E1g\u00E1s/Besz\u00FAr\u00E1s funkci\u00F3k nem \u00E9rhet\u0151ek el Mozilla \u00E9s Firefox alatt.\nK\u00EDv\u00E1n t\u00F6bbet tudni err\u0151l a t\u00E9m\u00E1r\u00F3l?",
clipboard_no_support:"Jelenleg nem t\u00E1mogatja a b\u00F6ng\u00E9sz\u0151je, haszn\u00E1lja a billenty\u0171kombin\u00E1ci\u00F3kat helyette.",
popup_blocked:"A felugr\u00F3 ablakok tilt\u00E1sa miatt nem siker\u00FClt megjelen\u00EDteni egy, az alkalmaz\u00E1shoz sz\u00FCks\u00E9ges ablakot. Enged\u00E9lyezze a b\u00F6ng\u00E9sz\u0151j\u00E9ben a felugr\u00F3 ablakokat, hogy minden funkci\u00F3t haszn\u00E1lhasson.",
invalid_data:"Hiba: \u00C9rv\u00E9nytelen adatok, pirossal jel\u00F6lve.",
more_colors:"T\u00F6bb sz\u00EDn"
},
contextmenu:{
align:"Igaz\u00EDt\u00E1s",
left:"Balra",
center:"K\u00F6z\u00E9pre",
right:"Jobbra",
full:"Sorkiz\u00E1r\u00E1s"
},
insertdatetime:{
date_fmt:"%Y.%m.%d.",
time_fmt:"%H:%M:%S",
insertdate_desc:"D\u00E1tum besz\u00FAr\u00E1sa",
inserttime_desc:"Id\u0151 besz\u00FAr\u00E1sa",
months_long:"janu\u00E1r,febru\u00E1r,m\u00E1rcius,\u00E1prilis,m\u00E1jus,j\u00FAnius,j\u00FAlius,augusztus,szeptember,okt\u00F3ber,november,december",
months_short:"jan,feb,m\u00E1r,\u00E1pr,m\u00E1j,j\u00FAn,j\u00FAl,aug,szept,okt,nov,dec",
day_long:"vas\u00E1rnap,h\u00E9tf\u0151,kedd,szerda,cs\u00FCt\u00F6rt\u00F6k,p\u00E9ntek,szombat,vas\u00E1rnap",
day_short:"V,H,K,Sze,Cs,P,Szo,V"
},
print:{
print_desc:"Nyomtat\u00E1s"
},
preview:{
preview_desc:"El\u0151n\u00E9zet"
},
directionality:{
ltr_desc:"Balr\u00F3l jobbra",
rtl_desc:"Jobbr\u00F3l balra"
},
layer:{
insertlayer_desc:"\u00DAj r\u00E9teg besz\u00FAr\u00E1sa",
forward_desc:"Mozgat\u00E1s el\u0151re",
backward_desc:"Mozgat\u00E1s h\u00E1tra",
absolute_desc:"Abszol\u00FAt poz\u00EDci\u00F3 ki-/bekapcsol\u00E1sa",
content:"\u00DAj r\u00E9teg..."
},
save:{
save_desc:"Ment\u00E9s",
cancel_desc:"\u00D6sszes v\u00E1ltoz\u00E1s visszavon\u00E1sa"
},
nonbreaking:{
nonbreaking_desc:"Nemsort\u00F6r\u0151 sz\u00F3k\u00F6z besz\u00FAr\u00E1sa"
},
iespell:{
iespell_desc:"Helyes\u00EDr\u00E1s-ellen\u0151rz\u00E9s futtat\u00E1sa",
download:"ieSpell nem tal\u00E1lhat\u00F3. Telep\u00EDti most?"
},
advhr:{
advhr_desc:"V\u00EDzszintes vonal"
},
emotions:{
emotions_desc:"Hangulatjelek"
},
searchreplace:{
search_desc:"Keres\u00E9s",
replace_desc:"Keres\u00E9s/Csere"
},
advimage:{
image_desc:"K\u00E9p besz\u00FAr\u00E1sa/szerkeszt\u00E9se"
},
advlink:{
link_desc:"Link besz\u00FAr\u00E1sa/szerkeszt\u00E9s"
},
xhtmlxtras:{
cite_desc:"Id\u00E9zet",
abbr_desc:"R\u00F6vid\u00EDt\u00E9s",
acronym_desc:"Bet\u0171sz\u00F3",
del_desc:"T\u00F6r\u00F6lt",
ins_desc:"Besz\u00FArt",
attribs_desc:"Tulajdons\u00E1gok besz\u00FAr\u00E1sa/szerkeszt\u00E9se"
},
style:{
desc:"CSS st\u00EDlus szerkeszt\u00E9se"
},
paste:{
paste_text_desc:"Besz\u00FAr\u00E1s sz\u00F6vegk\u00E9nt",
paste_word_desc:"Besz\u00FAr\u00E1s Wordb\u0151l",
selectall_desc:"Mindent kijel\u00F6l",
plaintext_mode_sticky:"Paste is now in plain text mode. Click again to toggle back to regular paste mode. After you paste something you will be returned to regular paste mode.",
plaintext_mode:"Paste is now in plain text mode. Click again to toggle back to regular paste mode."
},
paste_dlg:{
text_title:"Haszn\u00E1lja a Ctrl+V-t a billenty\u0171zet\u00E9n a beilleszt\u00E9shez.",
text_linebreaks:"Sort\u00F6r\u00E9sek megtart\u00E1sa",
word_title:"Haszn\u00E1lja a Ctrl+V-t a billenty\u0171zet\u00E9n a beilleszt\u00E9shez."
},
table:{
desc:"T\u00E1bl\u00E1zat besz\u00FAr\u00E1sa/szerkeszt\u00E9se",
row_before_desc:"Sor besz\u00FAr\u00E1sa el\u00E9",
row_after_desc:"Sor besz\u00FAr\u00E1sa ut\u00E1na",
delete_row_desc:"Sor t\u00F6rl\u00E9se",
col_before_desc:"Oszlop besz\u00FAr\u00E1sa el\u00E9",
col_after_desc:"Oszlop besz\u00FAr\u00E1sa ut\u00E1na",
delete_col_desc:"Oszlop t\u00F6rl\u00E9se",
split_cells_desc:"Cell\u00E1k feloszt\u00E1sa",
merge_cells_desc:"Cell\u00E1k \u00F6sszevon\u00E1sa",
row_desc:"Sor tulajdons\u00E1gai",
cell_desc:"Cella tulajdons\u00E1gai",
props_desc:"T\u00E1bl\u00E1zat tulajdons\u00E1gai",
paste_row_before_desc:"Sor bem\u00E1sol\u00E1sa el\u00E9",
paste_row_after_desc:"Sor bem\u00E1sol\u00E1sa ut\u00E1na",
cut_row_desc:"Sor kiv\u00E1g\u00E1sa",
copy_row_desc:"Sor m\u00E1sol\u00E1sa",
del:"T\u00E1bl\u00E1zat t\u00F6rl\u00E9se",
row:"Sor",
col:"Oszlop",
cell:"Cella"
},
autosave:{
unload_msg:"A m\u00F3dos\u00EDt\u00E1sok nem lesznek mentve, ha elhagyja az oldalt.",
restore_content:"Restore auto-saved content.",
warning_message:"If you restore the saved content, you will lose all the content that is currently in the editor.\n\nAre you sure you want to restore the saved content?."
},
fullscreen:{
desc:"Teljesk\u00E9perny\u0151s m\u00F3d ki-/bekapcsol\u00E1sa"
},
media:{
desc:"Be\u00E1gyazott m\u00E9dia besz\u00FAr\u00E1sa/szerkeszt\u00E9se",
edit:"Be\u00E1gyazott m\u00E9dia szerkeszt\u00E9se"
},
fullpage:{
desc:"Dokumentum tulajdons\u00E1gai"
},
template:{
desc:"Sablon beilleszt\u00E9se"
},
visualchars:{
desc:"Vizu\u00E1lis vez\u00E9rl\u0151karakterek be/ki."
},
spellchecker:{
desc:"Helyes\u00EDr\u00E1s-ellen\u0151rz\u0151 ki-/bekapcsol\u00E1sa",
menu:"Helyes\u00EDr\u00E1s-ellen\u0151rz\u0151 tulajdons\u00E1gai",
ignore_word:"Sz\u00F3 kihagy\u00E1sa",
ignore_words:"Mindet kihagy",
langs:"Nyelvek",
wait:"K\u00E9rem, v\u00E1rjon...",
sug:"Aj\u00E1nl\u00E1sok",
no_sug:"Nincs aj\u00E1nl\u00E1s",
no_mpell:"Nem tal\u00E1ltam helyes\u00EDr\u00E1si hib\u00E1t."
},
pagebreak:{
desc:"Oldalt\u00F6r\u00E9s besz\u00FAr\u00E1sa."
},
advlist:{
types:"Types",
def:"Default",
lower_alpha:"Lower alpha",
lower_greek:"Lower greek",
lower_roman:"Lower roman",
upper_alpha:"Upper alpha",
upper_roman:"Upper roman",
circle:"K\u00F6r",
disc:"Lemez",
square:"Square"
}}});