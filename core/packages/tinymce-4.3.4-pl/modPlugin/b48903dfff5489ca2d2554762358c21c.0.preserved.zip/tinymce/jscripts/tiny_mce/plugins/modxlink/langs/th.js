tinyMCE.addI18n('th.modxlink',{
    link_desc:"Insert/edit link"
});