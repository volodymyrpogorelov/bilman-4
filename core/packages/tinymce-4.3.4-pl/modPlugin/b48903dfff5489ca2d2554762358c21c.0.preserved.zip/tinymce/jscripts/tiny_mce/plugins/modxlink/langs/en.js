tinyMCE.addI18n('en.modxlink',{
    link_desc:"Insert/edit link"
});