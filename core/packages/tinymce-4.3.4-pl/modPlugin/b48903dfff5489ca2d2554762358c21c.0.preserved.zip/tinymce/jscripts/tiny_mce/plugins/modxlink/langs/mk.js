tinyMCE.addI18n('mk.modxlink',{
    link_desc:"Insert/edit link"
});