tinyMCE.addI18n('es.modxlink',{
    link_desc:"Insert/edit link"
});